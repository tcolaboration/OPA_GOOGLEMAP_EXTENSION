/* Developed by Radu Marinache -  radu.marinache@oracle.com  CX Hub - Apps Tech - 2019*/ 

/*SET UP VARIABLES */
var GoogleMapKey = "<GOOGLE MAP API>"
var centerLatitude = 52.481154;
var centerLongitude = -1.899120;
var markerIcon = "https://i.ibb.co/yFxG6X0/maps-and-flags.png";
/******************************************************************************/

var keepLat="";
var keepLong="";



function addAPI(){
console.log("---------------------ADD API------------------------")		
if(document.getElementById("scriptA")){
	
var mapScript = document.createElement('script');
console.log('--> Script was set');
mapScript.setAttribute('type','text/javascript')
mapScript.setAttribute('src','https://maps.googleapis.com/maps/api/js?sensor=false&key='+GoogleMapKey);
document.head.appendChild(mapScript);


var JSScript = document.createElement('script');
JSScript.setAttribute('type','text/javascript')
JSScript.setAttribute('src','https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js');
document.head.appendChild(JSScript);	



	
}

	
	
}


function addButton() {
	if(!document.getElementById('searchButton')){
	var count = localStorage.getItem('countIT');
    var objTo = document.getElementById("insertButton");
    var divtest = document.createElement("DIV");
	divtest.setAttribute("id", "searchButton");
    divtest.innerHTML = "Search";
	divtest.setAttribute("style","width:250px;text-overflow: ellipsis; white-space: nowrap;line-height: 1;cursor: pointer;padding: 0.7em 1.2em;border: none;text-decoration: none;-webkit-appearance: none;flex: 0 0 auto;text-align: center;font-size: 16px;font-weight: normal;color: rgb(255, 255, 255);background: rgb(199, 73, 67, 0.91);font-style: normal;border-radius: 6px;margin-left: 0px;visibility: visible;outline: none;")
    divtest.setAttribute("onclick","searchButtonFunction()");
	objTo.appendChild(divtest);
	console.log('Add Button')
	}
}


function addSDE(){
	var count = localStorage.getItem('countIT');
	  if (count != '1') {
	setTimeout(function() {addButton();
	console.log('addSearchButton')
	}, 2000);
}

	
}



function renderGoogleMap() {
	
    console.log("---------------------Screen CHECK------------------------")
    var count = localStorage.getItem('countIT');

    if (document.getElementById("Location")) {

        console.log("---------------------MAP SCREEN------------------------")
        document.getElementById("dvMap").style.width = "700px";
        document.getElementById("dvMap").style.height = "500px";
        addSDE();


        var mapOptions = {
            center: new google.maps.LatLng(centerLatitude,centerLongitude),
            zoom: 8,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };


        var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
        var latRClick;
        var lngRClick;
        var Address;


        var geocoder = new google.maps.Geocoder;
        var infoWindow = new google.maps.InfoWindow();


        google.maps.event.addListener(map, "rightclick", function(event) {

            var marker1 = [];

            latRClick = event.latLng.lat();
            lngRClick = event.latLng.lng();
			 
			keepLat=latRClick;
            keepLong=lngRClick;
			
            console.log("Lat=" + latRClick + "; Lng=" + lngRClick);

            var latlng1 = {
                lat: latRClick,
                lng: lngRClick
            };
            geocoder.geocode({
                'location': latlng1
            }, function(results, status) {
                if (status === 'OK') {
                    if (results[0]) {
                        Address = results[0].formatted_address;


                        marker1.push({
                            'title': Address,
                            'lat': latRClick,
                            'lng': lngRClick,
                            'description': Address
                        });
                        addMarkers(marker1)


                        var inputs = document.getElementsByTagName('input');
                        for (let u = 0; u < inputs.length; u++) {
                            inputs[0].value = Address;

                        }
                        localStorage.setItem('TheAddress', Address);



                        console.log(results[0].formatted_address);
                    } else {
                        window.alert('There were no results found');
                    }
                } else {
                    window.alert('Can not find the address due to: ' + status);
                }
            });

        });

      
        function addMarkers(marker1) {

            var lat_lng = new Array();
            for (n = 0; n < 1; n++) {

                var data = marker1[n];

                var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                lat_lng.push(myLatlng);
                var marker = new google.maps.Marker({
                    position: myLatlng,
                    map: map,
                    title: data.title,
                    draggable: true,
                    animation: google.maps.Animation.DROP,
                    icon: markerIcon
                });
                (function(marker, data) {
                    google.maps.event.addListener(marker, "click", function(e) {
                        infoWindow.setContent(data.description);
                        infoWindow.open(map, marker);
                    });
                })(marker, data);

                google.maps.event.addListener(marker, 'dragend', function(event) {

                    latRClick = event.latLng.lat();
                    lngRClick = event.latLng.lng();
					
					localStorage.setItem('keepLat', latRClick);
					localStorage.setItem('keepLong', lngRClick);
					
					keepLat=latRClick;
                    keepLong=lngRClick;

                    var latlng1 = {
                        lat: latRClick,
                        lng: lngRClick
                    };

                    geocoder.geocode({
                        'location': latlng1
                    }, function(results, status) {
                        if (status === 'OK') {
                            if (results[0]) {
                                Address = results[0].formatted_address;
                                var inputs = document.getElementsByTagName('input');
                                for (let u = 0; u < inputs.length; u++) {
                                    inputs[0].value = Address;
                                }
                                infoWindow.setContent(Address);
                                localStorage.setItem('TheAddress', Address);

                                console.log(results[0].formatted_address);
                            } else {
                                window.alert('There were no results found');
                            }
                        } else {
                            window.alert('Can not find the address due to: ' + status);
                        }
                    });




                    console.log("Lat=" + latRClick + "; Lng=" + lngRClick);
                    console.log("Dragged")
                });



            }

        }




        count = '1';
    }




    if (count != '1') {
        window.setTimeout(renderGoogleMap, 1000);
    }
}


function Count() {
    if (!document.getElementById("Location")) {
        localStorage.setItem('countIT', "0");
        renderGoogleMap();
    }
    window.setTimeout(Count, 2000);
}



OraclePolicyAutomation.AddExtension({
    customInput: function(control, interview) {
        if (control.getProperty("Lat") == "Lat") {
            control.setValue(localStorage.getItem('keepLat'));
			

        }
		
		   if (control.getProperty("Lon") == "Lon") {
            control.setValue(localStorage.getItem('keepLong'));

        }
		
		  if (control.getProperty("L1") == "L1") {
            control.setValue("Type an address and press F4 to search");

        }
		
    }
});




function geocodeAddr(addressToGeocode) {
    return $.ajax({
        url: 'https://maps.google.com/maps/api/geocode/json' + '?address=' + addressToGeocode + "&key=" + GoogleMapKey,
        success: function(result) {
            console.log(result);
            return result;
            //return result.data.results[0].geometry.location.lat;
        },
        async: false
    })



}




function keyDown1() {
    if (document.getElementById("Location")) {

        var AddressSearch = document.getElementsByTagName('input');

        AddressSearch[0].addEventListener('keydown', function(event) {

            if (event.key === "F4") {

                var callGeocoding = geocodeAddr(AddressSearch[0].value);
                var latitude = callGeocoding.responseJSON.results[0].geometry.location.lat;
                var longitude = callGeocoding.responseJSON.results[0].geometry.location.lng;

                var marker2 = [];
                marker2.push({
                    'title': AddressSearch[0].value,
                    'lat': latitude,
                    'lng': longitude,
                    'description': AddressSearch[0].value
                });

                var mapOptions = {
                    center: new google.maps.LatLng(marker2[0].lat, marker2[0].lng),
                    zoom: 15,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var infoWindow = new google.maps.InfoWindow();
                var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
                var lat_lng = new Array();
                var geocoder = new google.maps.Geocoder;

                var data = marker2[0];
                var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                lat_lng.push(myLatlng);
                var marker = new google.maps.Marker({
                    position: myLatlng,
                    map: map,
                    title: data.title,
                    draggable: true,
                    animation: google.maps.Animation.DROP,
                    icon: markerIcon
                });
                (function(marker, data) {
                    google.maps.event.addListener(marker, "click", function(e) {
                        infoWindow.setContent(data.description);
                        infoWindow.open(map, marker);
                    });
                })(marker, data);

                google.maps.event.addListener(marker, 'dragend', function(event) {

                    latRClick = event.latLng.lat();
                    lngRClick = event.latLng.lng();

                    localStorage.setItem('keepLat', latRClick);
					localStorage.setItem('keepLong', lngRClick);

                   keepLat=latRClick;
                   keepLong=lngRClick;


                    var latlng1 = {
                        lat: latRClick,
                        lng: lngRClick
                    };

                    geocoder.geocode({
                        'location': latlng1
                    }, function(results, status) {
                        if (status === 'OK') {
                            if (results[0]) {
                                Address = results[0].formatted_address;
                                var inputs = document.getElementsByTagName('input');
                                for (let u = 0; u < inputs.length; u++) {
                                    inputs[0].value = Address;
                                }
                                infoWindow.setContent(Address);
                                localStorage.setItem('TheAddress', Address);

                                console.log(results[0].formatted_address);
                            } else {
                                window.alert('There were no results found');
                            }
                        } else {
                            window.alert('Can not find the address due to: ' + status);
                        }
                    });




                    console.log("Lat=" + latRClick + "; Lng=" + lngRClick);
                    console.log("Dragged")
                });




            }
        });



        AddressSearch[0].addEventListener('click', function(event) {
            AddressSearch[0].value = "";


        })

    }







    window.setTimeout(keyDown1, 3000);
}

//BUTTON SEARCH //
function searchButtonFunction() {
    if (document.getElementById("Location")) {

        var AddressSearch = document.getElementsByTagName('input');

       


                var callGeocoding = geocodeAddr(AddressSearch[0].value);
                var latitude = callGeocoding.responseJSON.results[0].geometry.location.lat;
                var longitude = callGeocoding.responseJSON.results[0].geometry.location.lng;

                var marker2 = [];
                marker2.push({
                    'title': AddressSearch[0].value,
                    'lat': latitude,
                    'lng': longitude,
                    'description': AddressSearch[0].value
                });

                var mapOptions = {
                    center: new google.maps.LatLng(marker2[0].lat, marker2[0].lng),
                    zoom: 15,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var infoWindow = new google.maps.InfoWindow();
                var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
                var lat_lng = new Array();
                var geocoder = new google.maps.Geocoder;

                var data = marker2[0];
                var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                lat_lng.push(myLatlng);
                var marker = new google.maps.Marker({
                    position: myLatlng,
                    map: map,
                    title: data.title,
                    draggable: true,
                    animation: google.maps.Animation.DROP,
                    icon: markerIcon
                });
                (function(marker, data) {
                    google.maps.event.addListener(marker, "click", function(e) {
                        infoWindow.setContent(data.description);
                        infoWindow.open(map, marker);
                    });
                })(marker, data);

                google.maps.event.addListener(marker, 'dragend', function(event) {

                    latRClick = event.latLng.lat();
                    lngRClick = event.latLng.lng();

                    var latlng1 = {
                        lat: latRClick,
                        lng: lngRClick
                    };

                    geocoder.geocode({
                        'location': latlng1
                    }, function(results, status) {
                        if (status === 'OK') {
                            if (results[0]) {
                                Address = results[0].formatted_address;
                                var inputs = document.getElementsByTagName('input');
                                for (let u = 0; u < inputs.length; u++) {
                                    inputs[0].value = Address;
                                }
                                infoWindow.setContent(Address);
                                localStorage.setItem('TheAddress', Address);

                                console.log(results[0].formatted_address);
                            } else {
                                window.alert('There were no results found');
                            }
                        } else {
                            window.alert('Can not find the address due to: ' + status);
                        }
                    });




                    console.log("Lat=" + latRClick + "; Lng=" + lngRClick);
                    console.log("Dragged")
                });




            
       



        AddressSearch[0].addEventListener('click', function(event) {
            AddressSearch[0].value = "";
        })

    }




    window.setTimeout(keyDown1, 3000);
}


//BUTTON SEARCH //





function makeMap(){
	setTimeout(function() { renderGoogleMap() ; }, 1000);	
}

document.addEventListener('DOMContentLoaded', addAPI, false);
document.addEventListener('DOMContentLoaded', keyDown1, false);
document.addEventListener('DOMContentLoaded', Count, false);
document.addEventListener('DOMContentLoaded', makeMap, false);