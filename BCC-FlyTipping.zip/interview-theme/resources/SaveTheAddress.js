OraclePolicyAutomation.AddExtension({
    customInput: function(control, interview) {
        if (control.getProperty("A1") == "A1") {

            control.setValue(localStorage.getItem('TheAddress'));

        }
    }
});